var x = [];

function setup() {
  createCanvas(500, 600);
  for (var i = 0; i < 1000; i++) { //lots of raindrops
    x[i] = random(-2000,700)   // negative number for starting so the raindrops keep coming
}
}

function draw() {
  background(74, 79, 117);
  let mx = mouseX
  
  for( var i = 0; i < x.length; i++) { //x.length for i<1000
    x[i] += 20
    var y = i * 5 // spread out the raindrops
    fill(255)
    stroke(255)
    frameRate(15)
    ellipse(y, x[i], 2, 30)
    
  }
    
  
  stroke(235, 237, 247)
  fill(235, 237, 247)
  quad(230,30, 250,30, 250,540, 230,540)
  quad(40,290, 450,290, 450,310, 40,310)
  
  stroke(144, 147, 166)
  fill(144, 147, 166)
  quad(0,540, 500,540, 500,600, 0,600)
  quad (0,0, 500,0, 500, 30, 0,30)
  quad(0,0, 0,600, 40,600, 40,0)
  quad(500,0, 500,600, 450,600, 450,0)
  
  
  fill(0)
  stroke(0)
  arc (440, 601, 250, 250, PI, 0, CHORD)
  circle(310,510,140)
  triangle(265,410,245,484,340,500)
  triangle(365,410,320,454,380,500)
  
  fill(0)
  strokeWeight(2)
  stroke(255, 204, 102)
  circle(275,500,60)
  circle(345,500,60)
  
  text("meow! i've counted at least " + x.length + " raindrops!!", 20, 580)

}
let bg;
let lucky; 
let fish;

// Load an image and create a p5.Image object.
function preload() {
  bg = loadImage("background.png");
  lucky = loadImage ("lucky.png");
 // fish = loadImage ("fishes.png")
}

function setup() {
  createCanvas(1000, 1000);
}

function draw() {
  image (bg, 0,0);
  //image (fish, 100,400, mouseX,200);
  
  textSize(25)
  fill(255)
  textFont('Courier New', 10);
  text ('🐟', 100,600);
  text ('hi!', 120,600);
  text ('🐟', 950,900);
  
  image (lucky, mouseX,mouseY,300,450);
  
}
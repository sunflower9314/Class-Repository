//click the canvas before the squares disappear! :)

let x = 20;
let y = 20;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  colorMode(RGB, 255,255,255,1);
  background(255,255,255);
 
   let space = 15;
   let c1 = ('#ff9d96');
   let c2 = ('#f5f384')
   let c3 = ('#83f3f7')
   
   strokeWeight (20);
   stroke (c1);
  for ( let x = space; x < 400; x += space) {
    for (let y = space; y < 400; y += space) {
      point (x,y)
    }
  }
    
 if (mouseIsPressed === true)
 { fill (c3)
  stroke(c3) }
 else {
  stroke (c2)
  fill (c2) }
  
  frameRate (4);
  square (46,x,100,1)
  x += 21;
  
 if (mouseIsPressed === true)
   {fill (c2)
   stroke (c2)}
 else 
   {fill (c3)
   stroke (c3)}
  
  frameRate(12);
  square (250,y,100,1)
  
  y += 21
  
  
   
 
}